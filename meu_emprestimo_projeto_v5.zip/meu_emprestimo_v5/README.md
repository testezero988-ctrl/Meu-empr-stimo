# Meu Empréstimo V5

V5 com interface mobile, modo local/offline, backup JSON e integração opcional com Supabase para login por e-mail/senha e sincronização.

## Configurar nuvem
1. Crie um projeto no Supabase.
2. No SQL Editor, execute `supabase/schema.sql`.
3. Abra o app e vá em Configurações.
4. Informe a URL do projeto e a chave **anon/public**.
5. Toque em Conectar. O app tenta entrar e, se a conta ainda não existir, oferece cadastro.

> Nunca coloque a `service_role key` no aplicativo. Use apenas a chave anon/public no cliente.

## Rodar como web/PWA
Sirva a pasta `www` por HTTPS/localhost. Abrir por `file://` pode impedir o service worker e recursos externos.

## Android
Com Node.js instalado:
`npm install`
`npx cap add android`
`npx cap sync android`
`npx cap open android`
Depois, no Android Studio, gere o APK.

## Observação
A V5 sincroniza as estruturas locais com o Supabase quando há sessão conectada. Para produção, recomenda-se evoluir a sincronização para reconciliação bidirecional, UUIDs e auditoria de alterações.
