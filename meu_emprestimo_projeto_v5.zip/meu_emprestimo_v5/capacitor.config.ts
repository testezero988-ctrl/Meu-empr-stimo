import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig={appId:'br.com.meuemprestimo.app',appName:'Meu Empréstimo',webDir:'www',server:{androidScheme:'https'}};export default config;
